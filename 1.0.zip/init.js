  document.addEventListener('DOMContentLoaded', function() {
    var elems = document.querySelectorAll('.modal');
  });

  // Or with jQuery

  $(document).ready(function(){
    $('.modal').modal();
  });

function gId(target) {
	return(document.getElementById(target))
}

var inputVers = 2
function createTag() {
	M.toast({html: 'You created a new tag! It must be filled in.'})
	var parent = gId("tagParent")
	var e = document.createElement("div")
	e.setAttribute("class","row searchbar hideOnGood")
	var e2 = document.createElement("div")
	e2.setAttribute("class","input-field col s6")
	e2.style.width = "100%"
	e.appendChild(e2)
	var eInput = document.createElement("input")
	eInput.id="search"
	eInput.setAttribute("onkeyup","this.value = this.value.toLowerCase();this.value = this.value.replace(/[^a-z,A-Z,-,_,0-9]/, '')")
	eInput.setAttribute("autocapitolize","off")
	eInput.type="text"
	eInput.id=inputVers + "input"
	e2.appendChild(eInput)
	var eLabel = document.createElement("label")
	eLabel.setAttribute("class","active")
	eLabel.setAttribute("for","search")
	eLabel.innerHTML = "Tag"
	e2.appendChild(eLabel)
	parent.appendChild(e)
	eInput.select()
	inputVers += 1
}


// <div class="row searchbar">
// 	<div class="input-field col s6" style="width:100%">
// 		<input id="search" type="text" class="">
// 		<label class="active" for="search">Tag</label>
// 	</div>
// </div>

function prepareSubmission() {
	var value_c = 0

	if(gId("1input").value != "") {
		value_c += 1
	} else {
		M.toast({html: 'At least one tag is required'})
	}
	if(gId("file").value != "") {
		value_c += 1
	} else {
		M.toast({html: 'You must upload an image'})
	}
	if (value_c == 2) {
		grabTag()
		gId("prepSub").style.display = "none"
		gId("sub").style.display = "block"
		gId("sub").style.width = "100%"
		hideEm()
	} else {}
}

function hideEm() {
	$('.hideOnGood').css('display', 'none')
	$('.newTag').css('display', 'none')
}

function repeatGrabTag() {
	grabTag()
}

var elT = 1
var target = null
function grabTag() {

	if(gId("1input") != null) {
		target = gId("1input").value + " "
	}
	if(gId("2input") != null) {
		target += gId("2input").value + " "
	}
	if(gId("3input") != null) {
		target += gId("3input").value + " "
	}
	if(gId("4input") != null) {
		target += gId("4input").value + " "
	}
	if(gId("5input") != null) {
		target = gId("5input").value + " "
	}
	if(gId("6input") != null) {
		target += gId("6input").value + " "
	}
	if(gId("7input") != null) {
		target += gId("7input").value + " "
	}
	if(gId("8input") != null) {
		target += gId("8input").value + " "
	}
	target += '" href="#modalImg" onclick="modalize(this.src)"'

	gId("tags").value = target

	target = gId(elT + "input")

}

function search(val) {
	if(val != "") {
		M.Toast.dismissAll();
		valClass = val
		valClass = valClass.toLowerCase()
		$('.imageP').css('display', 'none')
		$('[searchData*='+valClass+']').css('display', 'inline-block')
		M.toast({html: 'Be sure to scroll up if you dont see anything'})
	} else {
		$('.imageP').css('display', 'inline-block')
	}
}

function modalize(target) {
	gId("imgToShow").src = target
	gId("imgDownload").href = target
}

function searchClean(elem) {
	elem.value = elem.value.toLowerCase();
	elem.value = elem.value.replace(/[^a-z,-,_,0-9]/, '');
	search(elem.value);
	elem.style.display='block';
}