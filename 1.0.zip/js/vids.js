function getResultsVids() {
	
	if(document.getElementById(elC + 'input')!==null) {
	// It does exist
	var elCi = elC + "input"
	var eI = document.getElementById(elCi).value
	console.log(eI)
	console.log(elCi)
	elC = elC + 1
	tags.push(eI)
	repeatIt()
	
	} else {
	// it does not exist
	console.log(tags)
	}
}

var ary = 0

function exportResultsVids() {
	var els = document.getElementById("dumpingGround")
	if(tags.length > ary){
	els.innerHTML = els.innerHTML + tags[ary] + "\n"
	console.log(tags[ary])
	console.log(ary)
	ary = ary + 1
	repeatIt1()} else {console.log("done")}
}
function getFileVids() {
	var str = document.getElementById("fileToUploadVid").value;
	str = str.replace("C:\\fakepath\\", "");
	str = str.replace(" ","%20")
	str = str.replace(" ","%20")
	str = str.replace(" ","%20")
	str = str.replace(" ","%20")
	str = str.replace(" ","%20")
	str = str.replace(" ","%20")
	str = str.replace(" ","%20")
	str = str.replace(" ","%20")
	str = str.replace(" ","%20")
	str = str.replace(" ","%20")
	str = str.replace(" ","%20")
	str = str.replace(" ","%20")
	str = str.replace(" ","%20")
	str = str.replace(" ","%20")
	str = str.replace(" ","%20")
	str = str.replace(" ","%20")
	document.getElementById("fileInfo").innerHTML = str
	var file = str
}

function prepareVids() {
	var els = document.getElementById("dumpingGround")
	var tagsS = tags.toString()
	var tagsNC = tagsS.replace(/,/g , " ");
	var tagsNC = tagsNC.toLowerCase()
	var tagsNC = tagsNC + " imageD videoD searchable"
	var file = document.getElementById("fileInfo").innerHTML
	var str = "<div class='" + tagsNC + "'><center><img src='uploads/" + file + "' class='imageI videoI'></center></div>"
	document.getElementById("tagsFvids").value = str
}

function cleanupVids() {
	document.getElementById("tooltipVids").hidden = true
	document.getElementById("submitVids").disabled = false
}

function allFunctsVids() {
	getResultsVids()
	exportResultsVids()
	getFileVids()
	prepareVids()
	cleanupVids()
}