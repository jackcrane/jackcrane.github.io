var el = 2
function createTag() {
	var parent = document.getElementById("more-tags-yay")
	var tag = document.createElement("label")
	var e = document.createElement("div")
	var input = document.createElement("input")
	var del = document.createElement("a")
	e.className = "pure-control-group"
	e.id = el
	tag.setAttribute("for","tags")
	tag.innerHTML = " "
	input.id = el + "input"
	input.type = "text"
	input.placeholder = "Enter another tag"
	input.className = "tagInput"
	del.href = "javascript:deleteTag('" + el + "')"
	del.innerHTML = "Remove"
	del.style.marginLeft = "4px"
	e.appendChild(tag)
	e.appendChild(input)
	e.appendChild(del)
	parent.appendChild(e)

	el = el + 1
}

function createTagVid() {
	var parent = document.getElementById("more-tags-yay-vids")
	var tag = document.createElement("label")
	var e = document.createElement("div")
	var input = document.createElement("input")
	var del = document.createElement("a")
	e.className = "pure-control-group"
	e.id = el
	tag.setAttribute("for","tags")
	tag.innerHTML = " "
	input.id = el + "input"
	input.type = "text"
	input.placeholder = "Enter another tag"
	input.className = "tagInput"
	del.href = "javascript:deleteTag('" + el + "')"
	del.innerHTML = "Remove"
	del.style.marginLeft = "4px"
	e.appendChild(tag)
	e.appendChild(input)
	e.appendChild(del)
	parent.appendChild(e)

	el = el + 1
}


function deleteTag (elt) {
   var e = document.getElementById(elt)
   e.parentNode.removeChild(e);
}

function repeatIt() {
	getResults()
}

function repeatIt1() {
	exportResults()
}

var elC = 1
var tags = []
function getResults() {
	
	if(document.getElementById(elC + 'input')!==null) {
	// It does exist
	var elCi = elC + "input"
	var eI = document.getElementById(elCi).value
	console.log(eI)
	console.log(elCi)
	elC = elC + 1
	tags.push(eI)
	repeatIt()
	
	} else {
	// it does not exist
	console.log(tags)
	}
}

var ary = 0

function exportResults() {
	var els = document.getElementById("dumpingGround")
	if(tags.length > ary){
	els.innerHTML = els.innerHTML + tags[ary] + "\n"
	console.log(tags[ary])
	console.log(ary)
	ary = ary + 1
	repeatIt1()} else {console.log("done")}
}
function getFile() {
	var str = document.getElementById("fileToUpload").value;
	str = str.replace("C:\\fakepath\\", "");
	str = str.replace(" ","%20")
	str = str.replace(" ","%20")
	str = str.replace(" ","%20")
	str = str.replace(" ","%20")
	str = str.replace(" ","%20")
	str = str.replace(" ","%20")
	str = str.replace(" ","%20")
	str = str.replace(" ","%20")
	document.getElementById("fileInfo").innerHTML = ""
	document.getElementById("fileInfo").innerHTML = str
	var file = str
}

function prepare() {
	var els = document.getElementById("dumpingGround")
	var tagsS = tags.toString()
	var tagsNC = tagsS.replace(/,/g , " ");
	var tagsNC = tagsNC.toLowerCase()
	var tagsNC = tagsNC + " imageD searchable"
	var file = document.getElementById("fileInfo").innerHTML
	var bigRandomVariable = Math.floor(100000000 + Math.random() * 900000000);
	var str = "<div class='" + tagsNC + "'><center><img onclick='modalize(this.src)' src='uploads/"
	var str2 = "' class='imageI'></center></div>"
	document.getElementById("tagsF").value = str
	document.getElementById("tagsF2").value = str2
}

function cleanup() {
	document.getElementById("tooltip").hidden = true
	document.getElementById("submit").disabled = false
}

function allFuncts() {
	getResults()
	exportResults()
	getFile()
	prepare()
	cleanup()
}

function showIdeas() {
	document.getElementById("tagsIdeas").hidden = false
}

function showIdeasVids() {
	document.getElementById("tagsIdeasVids").hidden = false
}

document.getElementById('searchB').onkeydown = function(event) {
    if (event.keyCode == 13) {
    	find()
        document.getElementById('searchB').blur()
    }
}

function setCss() {
	var classN = arguments[0]
	
}

function find() {
	var classes = document.getElementById('searchB').value;
	classes = classes.toLowerCase()
	if(classes != "") {
	var classesN = "." + classes

	// console.log(classesN)
	$('.imageD').css("width","0")

	searchS(classes)
	}else{
		$('.imageD').css("width","24%")
		console.log("yay")
	}
	// $(classesN).css("visibility","initial !important")
	// document.getElementsByTagName(classesN)[0].removeAttribute("style", "visibility: hidden"); 

	// cssC.forEach(element => {
	//   element.removeAttribute('class','imageI');
	// });
	// var others = document.querySelectorAll('imageI')
	// others.forEach(element => {
	//   element.hidden = true
	// });
}

// Get the modal
         var modal = document.getElementById('myModal');
         
         // Get the button that opens the modal
         var btn = document.getElementById("myBtn");
         
         // Get the <span> element that closes the modal
         var span = document.getElementsByClassName("close")[0];
         
         // When the user clicks on the button, open the modal 
         btn.onclick = function() {
           modal.style.display = "block";
         }
         
         // When the user clicks on <span> (x), close the modal
         span.onclick = function() {
           modal.style.display = "none";
         }
         
         // When the user clicks anywhere outside of the modal, close it
         window.onclick = function(event) {
           if (event.target == modal) {
             modal.style.display = "none";
           }
         }

function video() {
         // Get the modal
         var modal = document.getElementById('myModalVideo');

         var span = document.getElementById('closeV')

         modal.style.display = 'block'
         
         // When the user clicks on <span> (x), close the modal
         span.onclick = function() {
           modal.style.display = "none";
         }
         
         // When the user clicks anywhere outside of the modal, close it
         window.onclick = function(event) {
           if (event.target == modal) {
             modal.style.display = "none";
           }
         }
        }
         
         function onFileSelected(event) {
         var filename = document.getElementById("fileToUpload").value
         var ext = filename.substring(filename.lastIndexOf('.')+1, filename.length) || filename;
         ext = ext.toLowerCase()
         console.log(ext)
         
         var selectedFile = event.target.files[0];
         var reader = new FileReader();
         
         if(ext == "mp4") {
         document.getElementById("myimage").src = ""
         document.getElementById("myvid").hidden = false
         var vidtag = document.getElementById("myvid");
         vidtag.title = selectedFile.name;
         
         reader.onload = function(event) {
         vidtag.src = event.target.result;
         };
         reader.readAsDataURL(selectedFile);
         
         
         } else {
         var imgtag = document.getElementById("myimage");
         
         reader.onload = function(event) {
         imgtag.src = event.target.result;
         };
         reader.readAsDataURL(selectedFile);
         }
         }

//


function modalize(targ) {
		    document.getElementById('colorHelp').hidden = true
	    document.getElementById('colorPick').value = "#25231e"
	    document.getElementById("imageC").style.backgroundColor = "#25231e"
	var c = document.createElement("img")
	c.setAttribute("src",targ)
	c.setAttribute("class","imageMi")
	e = document.getElementById("imageC")
	e.appendChild(c)
	console.log(e)
	var parent = document.getElementById("parent")
var height = document.getElementsByClassName("imageMi")[0].height
$(".imgModalContent").css("height",height)
if(height>500) {
	$(".imgModalContent").css("marginTop","5%")
}
if(height>700) {
	$(".imgModalContent").css("height","1000")
}
	parent.style.display = "block"
	window.onclick = function(event) {
	  if (event.target == parent) {
	    parent.style.display = "none";

	    e.innerHTML = ""
	  }
	}
}

var elC = 1
var tags = []
function getResultsVids() {
	
	if(document.getElementById(elC + 'inputVids')!==null) {
	// It does exist
	var elCi = elC + "inputVids"
	var eI = document.getElementById(elCi).value
	console.log(eI)
	console.log(elCi)
	elC = elC + 1
	tags.push(eI)
	repeatItVids()
	
	} else {
	// it does not exist
	console.log(tags)
	}
}

var ary = 0

function exportResultsVids() {
	var els = document.getElementById("dumpingGround")
	if(tags.length > ary){
	els.innerHTML = els.innerHTML + tags[ary] + "\n"
	console.log(tags[ary])
	console.log(ary)
	ary = ary + 1
	repeatIt1Vids()} else {console.log("done")}
}
function getFileVids() {
	var str = document.getElementById("fileToUploadVid").value;
	str = str.replace("C:\\fakepath\\", "");
	str = str.replace(" ","%20")
	str = str.replace(" ","%20")
	str = str.replace(" ","%20")
	str = str.replace(" ","%20")
	str = str.replace(" ","%20")
	str = str.replace(" ","%20")
	str = str.replace(" ","%20")
	str = str.replace(" ","%20")
	document.getElementById("fileInfo").innerHTML = ""
	document.getElementById("fileInfo").innerHTML = str
	var file = str
}

function prepareVids() {
	var els = document.getElementById("dumpingGround")
	var tagsS = tags.toString()
	var tagsNC = tagsS.replace(/,/g , " ");
	var tagsNC = tagsNC.toLowerCase()
	var tagsNC = tagsNC + " imageD searchable"
	var file = document.getElementById("fileInfo").innerHTML
	var str = "<div class='" + tagsNC + "'><center><video src='uploads/" + file + "' class='imageI videoI'></center></div>"
	document.getElementById("tagsF").value = str
}

function cleanupVids() {
	document.getElementById("tooltip").hidden = true
	document.getElementById("submitVids").disabled = false
}

function allFunctsVids() {
	getResultsVids()
	exportResultsVids()
	getFileVids()
	prepareVids()
	cleanupVids()
}
function repeatItVids() {
	getResults()
}

function repeatIt1Vids() {
	exportResults()
}