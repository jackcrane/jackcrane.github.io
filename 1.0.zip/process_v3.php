<?php

  // variables
  define('UPLOAD_DIR', 'uploads/'); 
  $fileName = $_FILES['file'];


  // function to rename file
  function update_file_name($file) 
  {
    $pos = strrpos($file,'.');
    $ext = substr($file,$pos); 
    $dir = strrpos($file,'/');
    $dr  = substr($file,0,($dir+1)); 

    $arr = explode('/',$file);
    $fName = trim($arr[(count($arr) - 1)],$ext);

    $exist = FALSE;
    $i = 2;
    
    while(!$exist)
    {
      $file = $dr.$fName.'_'.$i.$ext;
      
      if(!file_exists($file))
        $exist = TRUE;
      
      $i++;
    }

    return $file;
  }




  // check for which action should be taken if file already exist
  if(file_exists(UPLOAD_DIR . $fileName['name'])) {
    $updatedFileName = update_file_name(UPLOAD_DIR.$fileName['name']);
    move_uploaded_file($fileName['tmp_name'], $updatedFileName);

    echo "Upload successful!";
    echo "File uploaded as: " . $updatedFileName;
    writeDoc($updatedFileName);
    //Message: SUCCESS UPLOAD and RENAME
  } else {
    // No rename necessary
    move_uploaded_file($fileName['tmp_name'], UPLOAD_DIR.$fileName['name']);
    
    //Message: SUCCESS UPLOAD
    echo "Upload successful!";
    echo "File uploaded as: " . $fileName['name'];
    writeDoc('uploads/' . $fileName['name']);
  }

function writeDoc($fNameP) {
  $handle = fopen("uploads/data.txt","a");
  $classes = $_POST['tags'];
  $element = '<img src="' . $fNameP . '" searchData="' . $classes . ' class="imageP modal-trigger">';
  if (strpos($element, '<img src="uploads/_2uploads/" class="') == false) {
    echo 'true';
    fwrite($handle, $element);
    Fwrite($handle, "\n");
} else {
  echo 'there was no file uploaded.';
}
  

}
echo "<script>document.location.href = document.referrer</script>"
?>

