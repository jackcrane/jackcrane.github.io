# CatalogQueryFilteredItemsCustomAttributeFilter

### Description



## Properties
Name | Getter | Setter | Type | Description | Notes
------------ | ------------- | ------------- | ------------- | ------------- | -------------
**filter_type** | getFilterType() | setFilterType($value) | **string** | See [CatalogQueryFilteredItemsCustomAttributeFilterFilterType](#type-catalogqueryfiltereditemscustomattributefilterfiltertype) for possible values | [optional] 
**custom_attribute_definition_ids** | getCustomAttributeDefinitionIds() | setCustomAttributeDefinitionIds($value) | **string[]** |  | [optional] 
**custom_attribute_value_exact** | getCustomAttributeValueExact() | setCustomAttributeValueExact($value) | **string** |  | [optional] 
**custom_attribute_value_prefix** | getCustomAttributeValuePrefix() | setCustomAttributeValuePrefix($value) | **string** |  | [optional] 
**custom_attribute_min_value** | getCustomAttributeMinValue() | setCustomAttributeMinValue($value) | **string** |  | [optional] 
**custom_attribute_max_value** | getCustomAttributeMaxValue() | setCustomAttributeMaxValue($value) | **string** |  | [optional] 

Note: All properties are protected and only accessed via getters and setters.

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

