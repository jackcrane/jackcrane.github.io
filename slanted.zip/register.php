<?php
// Include config file
require_once "assets/config.php";

if(isset($_GET["returnto"])===true) {
    $returnto = $_GET["returnto"];
} else {
    $returnto = "getslanted.php";
}
 
// Define variables and initialize with empty values
$username = $password = $fname = $confirm_password = "";
$username_err = $password_err = $fname_err = $confirm_password_err = "";
 
// Processing form data when form is submitted
if($_SERVER["REQUEST_METHOD"] == "POST"){
 
	if(empty(trim($_POST["fname"]))){
        $fname_err = "Please enter name.";
        $errstylefname = "border:2px dashed red;margin-bottom:3%;";
    } else{
        $fname = trim($_POST["fname"]);
    }

    // Validate username
    if(empty(trim($_POST["username"]))){
        $username_err = "Please enter an email.";
        $errstyleusername = "border:2px dashed red;margin-bottom:3%;";
    } else{
        // Prepare a select statement
        $sql = "SELECT id FROM users WHERE username = ?";
        
        if($stmt = mysqli_prepare($link, $sql)){
            // Bind variables to the prepared statement as parameters
            mysqli_stmt_bind_param($stmt, "s", $param_username);
            
            // Set parameters
            $param_username = trim($_POST["username"]);
            
            // Attempt to execute the prepared statement
            if(mysqli_stmt_execute($stmt)){
                /* store result */
                mysqli_stmt_store_result($stmt);
                
                if(mysqli_stmt_num_rows($stmt) == 1){
                    $username_err = "An account has already been made under this email. <a href='login.php' class='normala'>Login</a>";
                    $errstyleusername = "border:2px dashed red;margin-bottom:3%;";
                } else{
                    $username = trim($_POST["username"]);
                }
            } else{
                echo "Oops! Something went wrong. Please try again later.";
            }

            // Close statement
            mysqli_stmt_close($stmt);
        }
    }
    
    // Validate password
    if(empty(trim($_POST["password"]))){
        $password_err = "Please enter a password.";
        $errstylepassword = "border:2px dashed red;margin-bottom:3%;";
    } elseif(strlen(trim($_POST["password"])) < 8){
        $password_err = "Password must have at least 8 characters.";
        $errstylepassword = "border:2px dashed red;margin-bottom:3%;";
    } else{
        $password = trim($_POST["password"]);
    }
    
    // Validate confirm password
    if(empty(trim($_POST["confirm_password"]))){
        $confirm_password_err = "Please confirm password.";
        $errstylerepeatpassword = "border:2px dashed red;margin-bottom:3%;";
    } else{
        $confirm_password = trim($_POST["confirm_password"]);
        if(empty($password_err) && ($password != $confirm_password)){
            $confirm_password_err = "Password did not match.";
            $errstylerepeatpassword = "border:2px dashed red;margin-bottom:3%;";
        }
    }
    
    // Check input errors before inserting in database
    if(empty($username_err) && empty($password_err) && empty($confirm_password_err) && empty($fname_err)){
        
        // Prepare an insert statement
        $sql = "INSERT INTO users (username, password, fname, accountrank, paid, active) VALUES (?, ?, ?, ?, ?, ?)";
        
        if($stmt = mysqli_prepare($link, $sql)){
            // Bind variables to the prepared statement as parameters
            mysqli_stmt_bind_param($stmt, "sssibb", $param_username, $param_password, $param_fname, $accountrank, $paid, $active);
            
            // Set parameters
            $param_username = $username;
            $param_password = password_hash($password, PASSWORD_DEFAULT); // Creates a password hash

            $accountrank = 0;
            $paid = false;
            $active = true;
            $param_fname = $fname;
            
            // Attempt to execute the prepared statement
            if(mysqli_stmt_execute($stmt)){
                // Redirect to login page
                header("location: login.php?returnto=".$_POST["returnto"]);
            } else{
                echo "Something went wrong. Please try again later.";
            }

            // Close statement
            mysqli_stmt_close($stmt);
        }
    }
    
    // Close connection
    mysqli_close($link);
}
?>

<!DOCTYPE html>
<html>
<head>
	<?php $page="Register";include("assets/head.php");?>
</head>
<body>
    <div id="whitelist"></div>
	<section class="left">
		<div class="content">
			<div>
				<h1 class="thick"><span class="orange">Register for </span>Slanted</h1>
				<form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
					<center>
                    <input name='returnto' hidden value="<?php echo $returnto; ?>">
					<div class="formgroup" style='<?php echo($errstylefname); ?>'>
						<input name="fname" type="text" placeholder="Name" value="<?php echo $fname; ?>">
						<p class="errtext"><?php echo $fname_err; ?></p>
					</div>
					<div class="formgroup" style='<?php echo($errstyleusername); ?>'>
						<input type="text" name="username" placeholder="Email" value="<?php echo $username; ?>">
						<p class="errtext"><?php echo $username_err; ?></p>
					</div>
					<div class="formgroup" style='<?php echo($errstylepassword); ?>'>
						<input type="password" name="password" placeholder="Password (8 Characters)" value="<?php echo $password; ?>">
						<p class="errtext"><?php echo $password_err; ?></p>
					</div>
					<div class="formgroup" style='<?php echo($errstylerepeatpassword); ?>'>
						<input type="password" name="confirm_password" placeholder="Repeat password" value="">
						<p class="errtext"><?php echo $confirm_password_err; ?></p>
					</div>
					<div class="formgroup">
						<input type="submit" value="Log In">
					</div>
					</center>
				</form>
				<p>Already have an account? Login <a class="normala" href="login.php?returnto=<?php echo $returnto; ?>">here</a></p>
			</div>
		</div>
		<div class="illustration">
			<img src="assets/search.svg" alt="Man reading newspaper, from SLANTED">
		</div>
	</section>
	<?php include("assets/footers.php"); ?>
</body>
</html>