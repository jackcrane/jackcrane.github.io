<form action="receipt.php" method="POST">
	<input id="charge_id" name="charge_id" hidden value="charge_id">
	<input id="charge_amount" name="charge_amount" hidden value="charge_amount">
	<input id="charge_statement_descriptor" name="charge_statement_descriptor" hidden value="charge_statement_descriptor">
	<input id="charge_currency" name="charge_currency" hidden value="charge_currency">
	<input id="charge_seller_message" name="charge_seller_message" hidden value="charge_seller_message">
	<input id="charge_paid" name="charge_paid" hidden value="charge_paid">
	<input id="charge_brand" name="charge_brand" hidden value="charge_brand">
	<input id="charge_last4" name="charge_last4" hidden value="charge_last4">
	<input type="submit" value="Get a receipt" style="width:50%">
</form>