<!DOCTYPE html>
<html>
<head>
	<?php $page="basic";include("assets/head.php");?>
</head>
<body>
	<div id="whitelist"></div>
	<section class="left">
		<div class="content">
			<div>
				<h1 class="thick">Slanted</h1>
				<p class="thick">Whether we like it or not, the news we read is slanted.</p>
				<p>Authors and companies have political views that they stick to.</p>
				<p>Clear it up with <b class="orange">slanted</b></p><br><br>
				<a href="getslanted.php">Lets go!</a>
			</div>
		</div>
		<div class="illustration">
			<img src="assets/newspaper.svg" alt="Man reading newspaper, from SLANTED">
		</div>
	</section>
	<center><p>Scroll Down</p></center>
	<section class="right">
		<div class="content">
			<div>
				<h1>What <i>is</i> Slanted?</h1>
				<p>Slanted is a Google Chrome extension created to help you determine ideals.</p>
				<p>Slanted will create a recognizable, color coded, alert on search engines so you can read the article with the authors ideas in mind.</p>
			</div>
		</div>
		<div class="illustration">
			<img src="assets/phone2.svg" alt="Man reading newspaper, from SLANTED">
		</div>
	</section>
	<center><p>Scroll Down</p></center>
	<section class="left">
		<div class="content">
			<div>
				<h1 class="thick">Do <i>I</i> need Slanted?</h1>
				<p><span class="orange">Yes</span>. Of course.</p>
				<p>Even if you are not politically motivated, it is wise to know if an article's author is.</p>
				<p>An article will only show you <span class="orange">one side of the story</span>. Slanted will tell you what frame of mind to read the article with.</p><br><br>
				<a href="getslanted.php">Lets go!</a>
			</div>
		</div>
		<div class="illustration">
			<img src="assets/phone.svg" alt="Man reading newspaper, from SLANTED">
		</div>
	</section>
	<?php $returnto="index.php";include("assets/footers.php"); ?>
</body>
</html>