<title>Slanted | <?php echo $page; ?></title>
<link rel="icon" type="image/svg+xml" href="/assets/slanted.svg">
<link href="assets/style.css" rel="stylesheet">
<meta name="viewport" content="width=device-width, initial-scale=1">