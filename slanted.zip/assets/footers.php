<section class="footerS">
<?php
// Initialize the session
if (session_status() == PHP_SESSION_NONE) {
	session_start();
}
if(!isset($returnto)===true) {
	$returnto = "index.php";
}
// Check if the user is logged in, if not then redirect him to login page
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
	$text = "<a class='normala' href='login.php?returnto=";
	$text .= $returnto;
	$text .= "'>Login</a>";
} else {
	$text = "Hi, ".$_SESSION['fname']."<br><a class='normala' href='logout.php?returnto=".$returnto."'>Log Out</a>";
}
?>
	<div class="footerD">
		<div class="userWelcome"><?php echo $text; ?></div>
	</div>
</section>