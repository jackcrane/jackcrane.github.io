<script src="/slanted/v2/assets/card/dist/card.js"></script>
<div class="card-wrapper"></div>

<div class="form-container active">
  <form action="pay.php">
  	<center>
	  	<div class="formgroup">
		    <input placeholder="Card number" type="text" name="number">
		</div>
		<div class="formgroup">
		    <input placeholder="Full name" type="text" name="name">
		</div>
		<div class="formgroup">
		    <input placeholder="MM/YY" type="text" name="expiry">
		</div>
		<div class="formgroup">
		    <input placeholder="CVC" type="text" name="cvc">
		</div>
		<div class="formgroup">
			<input type="submit" value="Next">
		</div>
	</center>
  </form>
</div>

<script>
new Card({
  form: document.querySelector('form'),
  container: '.card-wrapper'
});
</script>