<?php
// Initialize the session
session_start();

if(isset($_GET["returnto"])===true) {
    $returnto = $_GET["returnto"];
} else {
    $returnto = "getslanted.php";
}
 
// Check if the user is already logged in, if yes then redirect him to welcome page
if(isset($_SESSION["loggedin"]) && $_SESSION["loggedin"] === true){
    header("location: index.php");
    exit;
}
 
// Include config file
require_once "assets/config.php";
 
// Define variables and initialize with empty values
$username = $password = "";
$username_err = $password_err = "";
 
// Processing form data when form is submitted
if($_SERVER["REQUEST_METHOD"] == "POST"){
 
    // Check if username is empty
    if(empty(trim($_POST["username"]))){
        $username_err = "Please enter username.";
        $errstyleusername = "border:2px dashed red;margin-bottom:3%;";
    } else{
        $username = trim($_POST["username"]);
    }

    // Check if password is empty
    if(empty(trim($_POST["password"]))){
        $password_err = "Please enter your password.";
        $errstylepassword = "border:2px dashed red;margin-bottom:3%;";
    } else{
        $password = trim($_POST["password"]);
    }
    
    // Validate credentials
    if(empty($username_err) && empty($password_err)){
        // Prepare a select statement
        $sql = "SELECT id, username, password, fname, created_at, accountrank FROM users WHERE username = ?";
        
        if($stmt = mysqli_prepare($link, $sql)){
            // Bind variables to the prepared statement as parameters
            mysqli_stmt_bind_param($stmt, "s", $param_username);
            
            // Set parameters
            $param_username = $username;
            
            // Attempt to execute the prepared statement
            if(mysqli_stmt_execute($stmt)){
                // Store result
                mysqli_stmt_store_result($stmt);
                
                // Check if username exists, if yes then verify password
                if(mysqli_stmt_num_rows($stmt) == 1){                    
                    // Bind result variables
                    mysqli_stmt_bind_result($stmt, $id, $username, $hashed_password, $fname, $created_at, $accountrank);
                    if(mysqli_stmt_fetch($stmt)){
                        if(password_verify($password, $hashed_password)){
                            // Password is correct, so start a new session
                            session_start();
                            
                            // Store data in session variables
                            $_SESSION["loggedin"] = true;
                            $_SESSION["id"] = $id;
                            $_SESSION["username"] = $username;  
                            $_SESSION["fname"] = $fname;
                            $_SESSION["created_at"] = $created_at;
                            $_SESSION["accountrank"] = $accountrank;
                            
                            // Redirect user to welcome page
                            header("location: ".$_POST["returnto"]);
                        } else{
                            // Display an error message if password is not valid
                            $password_err = "Incorrect password.";
                            $errstylepassword = "border:2px dashed red;margin-bottom:3%;";
                        }
                    }
                } else{
                    // Display an error message if username doesn't exist
                    $username_err = "No account found with that username.";
                    $errstyleusername = "border:2px dashed red;margin-bottom:3%;";
                }
            } else{
                echo "Oops! Something went wrong. Please try again later.";
            }

            // Close statement
            mysqli_stmt_close($stmt);
        }
    }
    
    // Close connection
    mysqli_close($link);
}
?>

<!DOCTYPE html>
<html>
<head>
	<?php $page="basic";include("assets/head.php");?>
</head>
<body>
    <div id="whitelist"></div>
	<section class="left">
		<div class="content">
			<div>
				<h1 class="thick"><span class="orange">Log in to </span>Slanted</h1>
				<form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
					<center>
					<input name='returnto' hidden value="<?php echo $returnto; ?>">
					<div class="formgroup" style='<?php echo($errstyleusername); ?>'>
						<input name="username" type="text" placeholder="Email" value="<?php echo $username; ?>">
						<p class="errtext"><?php echo $username_err; ?></p>
					</div>
					<div class="formgroup" style='<?php echo($errstylepassword); ?>'>
						<input name="password" type="password" placeholder="Password">
						<p class="errtext"><?php echo $password_err; ?></p>
					</div>
					<div class="formgroup">
						<input type="submit" value="Log In">
					</div>
					</center>
				</form>
				<p>Need an account? Register <a class="normala" href="register.php?returnto=<?php echo $returnto; ?>">here</a></p>
			</div>
		</div>
		<div class="illustration">
			<img src="assets/search.svg" alt="Man reading newspaper, from SLANTED">
		</div>
	</section>
	<?php include("assets/footers.php"); ?>
</body>
</html>