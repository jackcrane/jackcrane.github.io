<?php
require_once "assets/config.php";

// Initialize the session
session_start();
 
// Check if the user is logged in, if not then redirect him to login page
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
    header("location: login.php?returnto=getslanted.php");
    exit;
}
$payrank = $_SESSION["payrank"];
if($payrank==="basic") {
	$price = "free";
} else if($payrank==="plus") {
	$price = "$1:00";
} else if($payrank==="pro") {
	$price = "5:00";
}


// ********************************************************************************
//                              SQUARE payment handling

// require('connect-php-sdk/autoload.php');

// $access_token = 'EAAAEBXL4OHGzVQJpRsSWoEWvGOBEKUb497GQ9-UFKHP_bzbS76RQu-vR0d9CrGf'; # THIS IS SANDBOXED ASWELL ==================================================

// # setup authorization
// $api_config = new \SquareConnect\Configuration();
// $api_config->setHost("https://connect.squareup.com");
// $api_config->setAccessToken($access_token);
// $api_client = new \SquareConnect\ApiClient($api_config);

// # create an instance of the Payments API class
// $payments_api = new \SquareConnect\Api\PaymentsApi($api_client);
// $location_id = '1D2Z2MXN5B3ED'; # THIS IS NOT FOR PRODUCTION, ONLY TESTING. IT IS SANDBOXED IN SQUARE =============================================================
// $nonce = 'YOUR_NONCE';

// $body = new \SquareConnect\Model\CreatePaymentRequest();

// $amountMoney = new \SquareConnect\Model\Money();

// # Monetary amounts are specified in the smallest unit of the applicable currency.
// # This amount is in cents. It's also hard-coded for $1.00, which isn't very useful.
// $amountMoney->setAmount(100);
// $amountMoney->setCurrency("USD");

// $body->setSourceId($nonce);
// $body->setAmountMoney($amountMoney);
// $body->setLocationId($location_id);

// # Every payment you process with the SDK must have a unique idempotency key.
// # If you're unsure whether a particular payment succeeded, you can reattempt
// # it with the same idempotency key without worrying about double charging
// # the buyer.
// $body->setIdempotencyKey(uniqid());

// try {
//     $result = $payments_api->createPayment($body);
//     print_r($result);
// } catch (\SquareConnect\ApiException $e) {
//     echo "Exception when calling PaymentsApi->createPayment:";
//     var_dump($e->getResponseBody());
// }
?>