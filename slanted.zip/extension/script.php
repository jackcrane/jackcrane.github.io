<?php

// Initialize the session
session_start();
// echo "session started";
// if(isset($_GET["returnto"])===true) {
//     $returnto = $_GET["returnto"];
// } else {
//     $returnto = "getslanted.php";
// }
 
// Check if the user is already logged in, if yes then redirect him to welcome page
if(isset($_SESSION["loggedin"]) && $_SESSION["loggedin"] === true){
    // header("location: welcome.php");
    // echo "session already exists, destroying it";
    session_destroy();
    exit;
}
// echo "getting config";
// Include config file
require_once "../assets/config.php";
 
// Define variables and initialize with empty values
$username = $password = "";
$username_err = $password_err = "";
 
// Processing form data when form is submitted
if($_SERVER["REQUEST_METHOD"] == "GET"){
	// echo "ln 29\n";
    
    if(empty(trim($_GET["username"]))){
    	// echo "ln 32\n";
        $username_err = "Please enter username.";
        echo "noUn,,,";
        $errstyleusername = "border:2px dashed red;margin-bottom:3%;";
    } else{
        $username = trim($_GET["username"]);
        // echo "ln 37\n";
    }

    // Check if password is empty
    if(empty(trim($_GET["password"]))){
    	// echo "ln 42\n";
        $password_err = "Please enter your password.";
        echo "noPw,,,";
        $errstylepassword = "border:2px dashed red;margin-bottom:3%;";
    } else{
        $password = trim($_GET["password"]);
        // echo "ln 46\n";
    }
    
    // Validate credentials
    if(empty($username_err) && empty($password_err)){
        // Prepare a select statement
        $sql = "SELECT id, username, password, fname, created_at, accountrank FROM users WHERE username = ?";
        // echo "ln 54\n";

        if($stmt = mysqli_prepare($link, $sql)){
            // Bind variables to the prepared statement as parameters
            mysqli_stmt_bind_param($stmt, "s", $param_username);
            
            // Set parameters
            $param_username = $username;
            
            // Attempt to execute the prepared statement
            if(mysqli_stmt_execute($stmt)){
                // Store result
                mysqli_stmt_store_result($stmt);
                // echo "ln 67\n";
                // Check if username exists, if yes then verify password
                if(mysqli_stmt_num_rows($stmt) == 1){                    
                    // Bind result variables
                    // echo "ln 71\n";
                    mysqli_stmt_bind_result($stmt, $id, $username, $hashed_password, $fname, $created_at, $accountrank);
                    if(mysqli_stmt_fetch($stmt)){
                    	// echo "ln 74\n";
                        if(password_verify($password, $hashed_password)){
                            // Password is correct, so start a new session
                            // session_start();
                            
                            // Store data in session variables
                            $_SESSION["loggedin"] = true;
                            $_SESSION["id"] = $id;
                            $_SESSION["username"] = $username;  
                            $_SESSION["fname"] = $fname;
                            $_SESSION["created_at"] = $created_at;
                            $_SESSION["accountrank"] = $accountrank;
                            
                            // Redirect user to welcome page
                            // header("location: ".$_GET["returnto"]);
                            echo "good,,,".$fname.",,,".(float)$accountrank*(float)$_GET["ver"];
                        } else{
                            // Display an error message if password is not valid
                            $password_err = "Incorrect password.";
                            $errstylepassword = "border:2px dashed red;margin-bottom:3%;";
                            echo "incPw";
                        }
                    }
                } else{
                    // Display an error message if username doesn't exist
                    $username_err = "No account found with that username.";
                    $errstyleusername = "border:2px dashed red;margin-bottom:3%;";
                    echo "incUn,,,";
                }
            } else{
                echo "otherFailure,,,";
            }

            // Close statement
            mysqli_stmt_close($stmt);
        }
    }
    
    // Close connection
    mysqli_close($link);
} else {echo "postFail,,,";}

// var_dump($_GET);

// $username = $_GET["username"];
// $password = $_GET["password"];

// if(isset($_GET["submit"])) {

// } else {
// 	die();
// }

session_destroy();

?>