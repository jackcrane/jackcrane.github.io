<?php
// Initialize the session
session_start();
 
// Check if the user is logged in, if not then redirect him to login page
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
    header("location: login.php?returnto=pro.php");
    exit;
}
$_SESSION["payrank"]="pro";
?>

<!DOCTYPE html>
<html>
<head>
	<title>Slanted</title>
	<link href="assets/style.css" rel="stylesheet">
	<meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body>
	<div id="whitelist"></div>
	<section class="left">
		<div class="content">
			<div>
				<h1 class="thick">Slanted <span class="orange">Pro</span></h1>
				<div class="paymentbox">
					<p>Get slanted pro:</p>
					<h3>Slanted Pro</h3>
					<p>$5.00</p>
					<?php include("assets/payment.php"); ?>
					<p class="scrollI">Scroll...</p>
				</div>
			</div>
		</div>
		<div class="illustration">
			<img src="assets/ccard.svg" alt="Man reading newspaper, from SLANTED">
		</div>
	</section>
	<?php include("assets/footers.php"); ?>
</body>
</html>