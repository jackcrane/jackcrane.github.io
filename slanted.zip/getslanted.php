<?php
// Initialize the session
session_start();
 
// Check if the user is logged in, if not then redirect him to login page
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
    
}
?>

<!DOCTYPE html>
<html>
<head>
	<?php $page="Get Slanted";include("assets/head.php");?>
</head>
<body>
	<div id="whitelist"></div>
	<section class="left">
		<div class="content">
			<div>
				<h1 class="thick"><span class="orange">Get </span>Slanted</h1>
				<p class="thick">Whatever you need from slanted, we have it.</p>
				<p>Scroll down for options</p>
			</div>
		</div>
		<div class="illustration">
			<img src="assets/search.svg" alt="Man reading newspaper, from SLANTED">
		</div>
	</section>
	<center><p>Scroll Down</p></center>
	<section class="right grow">
		
		<div class="cardset">
			<div class="container">
				<div class="card">
					<div class="cardfull">
						<h2 class="orange">Base</h2>
						<?php
							if(isset($_SESSION["accountrank"])===true){
							if($_SESSION["accountrank"]===0){echo "<p class='green'>You have this level</p>";}
						} ?>
						<div class="featlist">
							<p>Features</p>
							<ul>
								<li>Works on the first page of Google</li>
								<li>Provides full access to categories</li>
								<li>Allows for delayed access to database updates</li>
							</ul>
							<p>Price: <span class="orange">FREE</span></p>
							<div class="acontainer"><br>
								<a href="basic.php">Get It!</a><br><br><br>
							</div>
						</div>
					</div>
				</div>
				<div class="card main">
					<div class="cardfull">
						<h2 class="orange">Plus</h2>
						<?php
							if(isset($_SESSION["accountrank"])===true){
							if($_SESSION["accountrank"]===1){echo "<p class='green'>You have this level</p>";}
						} ?>
						<div class="featlist">
							<p>Features</p>
							<ul>
								<li>Works on all pages of Google</li>
								<li>Works on Bing and Yahoo</li>
								<li>Provides full access to categories</li>
								<li>Allows for daily access to database updates</li>
								<li>Displays a warning unreliable sites</li>
							</ul>
							<p>Price: <span class="orange">$1.00</span></p>
							<div class="acontainer"><br>
								<a href="plus.php">Get It!</a><br><br><br>
							</div>
						</div>
					</div>
				</div>
				<div class="card">
					<div class="cardfull">
						<h2 class="orange">Pro</h2>
						<?php
							if(isset($_SESSION["accountrank"])===true){
							if($_SESSION["accountrank"]===2){echo "<p class='green'>You have this level</p>";}
						} ?>
						<div class="featlist">
							<p>Features</p>
							<ul>
								<li>All features of plus</li>
								<li>Guaranteed induction into the AI page screening system (still in development)</li>
								<li>Access to Betas</li>
								<li>Ratings on every webpage you visit</li>
							</ul>
							<p>Price: <span class="orange">$5.00</span></p>
							<div class="acontainer"><br>
								<a href="pro.php">Get It!</a><br><br><br>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
	<?php $returnto="getslanted.php";include("assets/footers.php"); ?>
</body>
</html>