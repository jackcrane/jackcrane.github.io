<?php
// Initialize the session
session_start();
 
// Check if the user is logged in, if not then redirect him to login page
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
    header("location: login.php?returnto=getslanted.php");
    exit;
}
$payrank = $_SESSION["payrank"];
if($payrank==="basic") {
	$price = "free";
} else if($payrank==="plus") {
	$price = "$1:00";
} else if($payrank==="pro") {
	$price = "5:00";
}

?>

<!DOCTYPE html>
<html>
<head>
	<title>Slanted</title>
	<link href="assets/style.css" rel="stylesheet">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<script>
		var prevalue=0
		function showBox(checked) {
			document.getElementById("couponBox").hidden = !checked
		}
	</script>
</head>
<body>
	<div id="whitelist"></div>
	<section class="left">
		<div class="content">
			<div>
				<h1 class="thick"><span class="orange">Buy</span> Slanted</h1>
				<p>You are purchasing <span class="orange">Slanted <?php echo $payrank; ?></span> for <span class="orange"><?php echo $price; ?></span></p>
				<center>
				<label class="checkcontainer">I have a coupon code
					<input type="checkbox" onchange="showBox(this.checked)">
					<span class="checkmark"></span>
				</label>
				<div class="formgroup">
					<input type="text" placeholder="Coupon Code" id="couponBox" hidden>
				</div>
				<div class="formgroup">
					<input type="submit" value="Buy!">
				</div>
				</center>
			</div>
		</div>
		<div class="illustration">
			<img src="assets/ccard.svg" alt="Man reading newspaper, from SLANTED">
		</div>
	</section>
	<?php include("assets/footers.php"); ?>
</body>
</html>