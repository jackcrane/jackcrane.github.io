<?php

// Initialize the session
session_start();
 
// Check if the user is logged in, if not then redirect him to login page
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
    header("location: login.php?returnto=getslanted.php");
    exit;
}
$payrank = $_SESSION["payrank"];
if($payrank==="basic") {
	$price = "free";
} else if($payrank==="plus") {
	$price = "$1:00";
} else if($payrank==="pro") {
	$price = "5:00";
}

?>

<!DOCTYPE html>
<html>
<head>
	<?php $page="Payment";include("assets/head.php");?>
</head>
<body>
	<div id="whitelist"></div>
	<section class="left">
		<div class="content">
			<div>
				<h1 class="thick"><span class="orange">Buy</span> Slanted</h1>
				<div id="successNotification" hidden>
					<p>Payment successful!</p>
					<form action="receipt.php" method="POST">
						<input id="charge_id" name="charge_id" hidden>
						<input id="charge_amount" name="charge_amount" hidden>
						<input id="charge_currency" name="charge_currency" hidden>
						<input id="charge_seller_message" name="charge_seller_message" hidden>
						<input id="charge_paid" name="charge_paid" hidden>
						<input id="charge_brand" name="charge_brand" hidden>
						<input id="charge_last4" name="charge_last4" hidden>
						<input type="submit" value="Get a receipt" style="width:50%">
					</form>
				</div>

				<div id="failureNotification">
					<p>Payment Failed</p>
					<div id="failureNotificationText"></div><br><br>
					<a href="">Submit an error report</a>
				</div>
				
			</div>
		</div>
		<div class="illustration">
			<img src="assets/ccard.svg" alt="Man reading newspaper, from SLANTED">
		</div>
	</section>
	<?php include("assets/footers.php"); ?>
</body>




<?php

require_once('assets/stripe/init.php');


// Set your secret key. Remember to switch to your live secret key in production!
// See your keys here: https://dashboard.stripe.com/account/apikeys
\Stripe\Stripe::setApiKey('sk_test_rDKQ55zWjn0ULyBmjvtwuV6b00aR19hKFs');

// Token is created using Stripe Checkout or Elements!
// Get the payment token ID submitted by the form:
$token = $_POST['stripeToken'];

$failed = false;
echo "<script>document.getElementById('failureNotificationText').innerHTML='";
try {
	$charge = \Stripe\Charge::create([
	  'amount' => 999,
	  'currency' => 'usd',
	  'description' => 'Example charge',
	  'source' => $token,
	]);
} catch(\Stripe\Exception\CardException $e) {
	
	echo 'Status is:' . $e->getHttpStatus() . '\n';
	echo 'Type is:' . $e->getError()->type . '\n';
	echo 'Code is:' . $e->getError()->code . '\n';
	// param is '' in this case
	echo 'Param is:' . $e->getError()->param . '\n';
	echo 'Message is:' . $e->getError()->message . '\n';
	$failed = true;
	} catch (\Stripe\Exception\RateLimitException $e) {
		$failed = true;
		echo 'We have a much larger load than expected. Please try again later';
	} catch (\Stripe\Exception\InvalidRequestException $e) {
		$failed = true;
		echo "API Error: Please contact us - Error code 925v";
	} catch (\Stripe\Exception\AuthenticationException $e) {
		$failed = true;
		echo "API Error: Please contact us - Error code 895h";
	} catch (\Stripe\Exception\ApiConnectionException $e) {
		$failed = true;
		echo "Network failure";
	} catch (\Stripe\Exception\ApiErrorException $e) {
		$failed = true;
		echo "Error. Please try again later.";
	} catch (Exception $e) {
		$failed = true;
		echo "Error. Please try again later.";
	}
echo "'</script>";
if(!$failed) {
	echo "<script>
	document.getElementById('failureNotification').hidden=true

	document.getElementById('successNotification').hidden=false
	var charge = ".json_encode($charge)."
	good()
	</script>";
}

?>

<script>
	function good() {
		console.log(good)
		document.getElementById("charge_id").value = charge.id
		document.getElementById("charge_amount").value = "$"+charge.amount/100
		document.getElementById("charge_currency").value = charge.currency
		document.getElementById("charge_seller_message").value = charge.calculated_statement_descriptor
		document.getElementById("charge_paid").value = charge.paid
		document.getElementById("charge_brand").value = charge.payment_method_details.card.brand
		document.getElementById("charge_last4").value = charge.payment_method_details.card.last4
	}
</script>

</html>