<!DOCTYPE html>
<html>
<head>
	<?php $page="Error 404";include("../assets/head.php");?>
</head>
<body>
	<div id="whitelist"></div>
	<section class="left">
		<div class="content">
			<div>
				<h1 class="thick" style="margin-bottom:0">Error <span class="orange"><code>404</code></span></h1><p>File not found</p><br><br>
				<p>Are you looking for...</p>
				<a class="normala" href="/index.php">Home</a><br>
				<a class="normala" href="/login.php">Login</a><br>
				<a class="normala" href="/getslanted.php">Get Slanted</a><br>
			</div>
		</div>
		<div class="illustration">
			<img src="../assets/failure.svg" alt="Man reading newspaper, from SLANTED">
		</div>
	</section>
</body>
</html>