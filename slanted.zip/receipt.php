<html>
<head>
	<?php $page="Receipt";include("assets/head.php");?>
	<style>
		td {
	padding:1em 0 0 0;
	vertical-align:bottom;
	background-image:radial-gradient(black 1px, white 0px);
	background-size: 8px 8px;
	background-repeat:repeat-x;
	background-position: left bottom;
	}
	td span {
		background-color:white;
	}
	td:first-child {
	text-align: left;
	font-weight: light;
	}
	
	td:first-child span{
	padding-right:.25em;
	}
	td:last-child {
	text-align:right;
	width:3em;
  	}
  	
  	td:last-child span{
	padding-left:.25em;
	font-weight:bold;
	}
	table {
		width:100%;
	}
	</style>
</head>
<body>
	<h2>Slanted Technology</h2>
	<h3 class="orange" style="margin-block-start: 0;">Receipt</h3>
	<div>
		<table>
			<tr>
				<td><span>Charge ID</span></td>
				<td><span><?php echo $_POST['charge_id']; ?></span></td>
			</tr>
			<tr>
				<td><span>Charge Amount</span></td>
				<td><span><?php echo $_POST['charge_amount']; ?></span></td>
			</tr>
			<tr>
				<td><span>Currency</span></td>
				<td><span><?php echo $_POST['charge_currency']; ?></span></td>
			</tr>
			<tr>
				<td><span>Seller Message</span></td>
				<td><span><?php echo $_POST['charge_seller_message']; ?></span></td>
			</tr>
			<tr>
				<td><span>Paid</span></td>
				<td><span><?php echo $_POST['charge_paid']; ?></span></td>
			</tr>
		</table>
		<table>
			<h3 class="orange">Card</h3>
			<tr>
				<td><span>Brand</span></td>
				<td><span><?php echo $_POST['charge_brand']; ?></span></td>
			</tr>
			<tr>
				<td><span>Last 4</span></td>
				<td><span><?php echo $_POST['charge_last4']; ?></span></td>
			</tr>
		</table>
		<h3 class="orange">Thank You!</h3>
		<p style="font-weight: lighter; padding:0;margin:0">If you have not yet gotten Slanted, get it from the Chrome Web Store and login!</p>
	</div>
</body>
</html>