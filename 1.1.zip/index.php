<!DOCTYPE html>
<html>
	<head>
		<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
		<link type="text/css" rel="stylesheet" href="materialize/css/materialize.min.css"  media="screen,projection"/>
		<link type="text/css" rel="stylesheet" href="css/style.css">
		<meta name="viewport" content="width=device-width, initial-scale=1.0"/>
		<script src="js/jscookie.js"></script>
	</head>

	<body>
		<div class="dashb">
			<div class="row searchbar">
				<div class="input-field col s6 tooltipped" style="width:95%">
					<input id="search" class="tooltipped" type="text" data-position="bottom" style="display:block!important" data-tooltop="Lowercase a-z, 0-9, -, _" onkeyup="searchClean(this)">
					<label class="active" for="search">Search</label>
				</div>
			</div>
			<a class="waves-effect waves-light btn modal-trigger colorTheme" href="#modal1" style="width:95%">Upload new image</a>
		</div>

		<div id="modalImg" class="modal">
			<img id="imgToShow">
			<div class="modal-footer">
				<a href="" id="imgDownload" class="waves-effect waves-blue btn-flat" download>Download image</a>
				<a href="#!" class="modal-close waves-effect waves-blue btn-flat">Close</a>
			</div>
		</div>

		<div id="settings" class="modal">
			<div class="modal-content">
				<h4>Settings</h4>
				Currently, the only setting we offer is "Color Scheme". You can use color scheme to change the colors of the buttons on this device. Changes are not applied on other devices.<br>Select "Color Scheme" then your color family, then choose from one of the many colors we offer.<br><br>
				<button class="btn colorTheme" onclick="$('#schemeOptions').removeClass('hidden')">Color Scheme</button><br><br>
				<hr>
				<div id="schemeOptions" class="hidden">
					<?php echo file_get_contents("colorOptions.txt") ?>
				</div>
				<div class="modal-footer">
					<a href="#!" class="modal-close waves-effect waves-blue btn-flat">Close</a>
				</div>
			</div>
		</div>

		<div id="modal1" class="modal">
			<form action="process_v3.php" method="POST" enctype="multipart/form-data">
			    <div class="modal-content">
			        <h4>Upload an image</h4>
			        <div class="file-field input-field">
				        <div class="btn colorTheme">
				            <span>File</span>
				        	<input id="file" name="file" type="file" accept="image/* video/*" required>
				        </div>
				        <div class="file-path-wrapper">
				        	<input class="file-path validate" type="text">
				        </div>
				    </div>
				    <div class="row searchbar hideOnGood">
						<div class="input-field col s6" style="width:100%">
							<input id="1input" type="text" class="" onkeyup="this.value = this.value.toLowerCase();this.value = this.value.replace(/[^a-z,-,_,0-9]/, '')" >
							<label class="active" for="search" required>Tag</label>
						</div>
					</div>
					<div id="tagParent"></div>
					<a class="waves-effect waves-light btn colorTheme newTag" href="javascript:createTag()" style="width:100%">Add another tag</a>
					<br><br><br>
					<a type="" hidden class="waves-effect waves-light btn colorTheme" href="javascript:prepareSubmission()" id="prepSub" style="width:100%">Prepare Submission</a>
					<button type="" hidden class="waves-effect waves-light btn colorTheme" style="display:none" id="sub" style="width:100%">Submit</button>
					<input name="tags" id="tags" hidden>
				</div>
			</form>
		    <div class="modal-footer">
		        <a href="javascript:location.reload()" class="modal-close waves-effect waves-blue btn-flat">Start Over</a>
		        <a href="#!" class="modal-close waves-effect waves-blue btn-flat">Cancel</a>
		    </div>
		</div>



		<center>
			<div class="images" id="photos">
				<?php echo file_get_contents("uploads/data.txt") ?>
			</div>
		</center>

		<div class="footer">
			<button style="float:right" data-target="settings" class="btn modal-trigger colorTheme">Settings</button>
		</div>


		<script type="text/javascript" src="materialize/js/materialize.min.js"></script>
		<script src="init.js"></script>
		<script></script>
	</body>
</html>
