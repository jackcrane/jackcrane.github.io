<?php
$target_dir = "uploads/";
$target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);
$uploadOk = 1;
$imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
// Check if image file is a actual image or fake image
echo("<style>body{background-color:black;}a{color:#ffc700;}span{color:red;}.err{color:red}.good{color:green}</style>");
if (file_exists($target_file)) {
    echo "<span class='err'>Sorry, file already exists.</span>";
    $uploadOk = 0;
}
// Allow certain file formats
if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
&& $imageFileType != "gif" && $imageFileType != "mp4" ) {
    echo "<span class='err'>Sorry, only JPG, JPEG, PNG, MP4 & GIF files are allowed.</span>";
    $uploadOk = 0;
}
// Check if $uploadOk is set to 0 by an error
if ($uploadOk == 0) {
    echo "Sorry, your file was not uploaded.";
// if everything is ok, try to upload file
} else {
    if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) {
        echo "<span class='good'>The file ". basename( $_FILES["fileToUpload"]["name"]). " has been uploaded.</span>";
        $handle = fopen("uploads/data.txt", "a");
        $classes = $_POST["classes"];
        Fwrite($handle, $classes);
        Fwrite($handle, "\n");
    } else {
        echo "Sorry, there was an error uploading your file.";
    }
}
echo($_FILES["fileToUpload"]["tmp_name"]);

$dir = "uploads/";

// Open a directory, and read its contents
if (is_dir($dir)){
  if ($dh = opendir($dir)){
    while (($file = readdir($dh)) !== false){
      if ($file == '.' or $file == '..') continue;
      // echo "<img class='imageRes' src='uploads/" . $file . "'>" . "<br>";
    }
    closedir($dh);
  }
}

// $handle = fopen("uploads/data.txt", "a");
// 	$classes = $_POST["classes"];
// 	Fwrite($handle, $classes);
// 	Fwrite($handle, "\n");

echo("<br><a href='index.php'>Back to page</a>");
?>
