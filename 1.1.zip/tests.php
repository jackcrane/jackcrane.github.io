<!DOCTYPE html>
<html>
<head>
  <title>TESTS</title>
  <script type="text/javascript" src="js/face-api.js"></script>
  
</head>
<body>
  <img id="myImage" src="uploads/Fear.jpg">
<script type="text/javascript">
const MODEL_URL = '/uploads'

await faceapi.loadSsdMobilenetv1Model(MODEL_URL)
await faceapi.loadFaceLandmarkModel(MODEL_URL)
await faceapi.loadFaceRecognitionModel(MODEL_URL)

const input = document.getElementById('myImage')
let fullFaceDescriptions = await faceapi.detectAllFaces(input).withFaceLandmarks().withFaceDescriptors()

console.log(fullFaceDescriptions)
</script>
</body>
</html>