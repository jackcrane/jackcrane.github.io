var run = 0
function searchS(classes) {
	var e = document.getElementsByClassName(classes)[run]
	var classesM = "." + classes
	console.log(e)
	if(e!=null) {
		//$(classesM).children().css({"width": "100%"});
		$(classesM).css({"width": "24%"});
		$(classes).css("width","24%")
		run = run+1
		repeatIn()
	}else{
		console.log(run)
		run = 0
	}
}
function repeatIn() {
	searchS()
	console.log("running")
}